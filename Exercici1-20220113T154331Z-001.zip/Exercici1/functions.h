
#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_
#define PI 3.141592
#endif /* FUNCTIONS_H_ */

float multiplicar(float);
float llegirNum();
