#include "functions.h"
//
float multiplicar(float radi){
	return (2*PI)*radi;
}

float llegirNum(){
	float radi2;
	printf("Introdueix el radi: \n");
	scanf("%f", &radi2);
	return radi2;
}
